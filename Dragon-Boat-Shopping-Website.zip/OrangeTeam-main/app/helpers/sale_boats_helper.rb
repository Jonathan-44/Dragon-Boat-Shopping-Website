module SaleBoatsHelper
end
