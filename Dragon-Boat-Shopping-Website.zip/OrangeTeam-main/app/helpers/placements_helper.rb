module PlacementsHelper
end
