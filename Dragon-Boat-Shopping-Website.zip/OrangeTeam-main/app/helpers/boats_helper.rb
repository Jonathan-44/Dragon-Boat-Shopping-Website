module BoatsHelper
end
