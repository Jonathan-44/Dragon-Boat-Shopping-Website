# == Schema Information
#
# Table name: dragon_races
#
#  id         :bigint           not null, primary key
#  date       :date
#  name       :string
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
require "test_helper"

class DragonRaceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
